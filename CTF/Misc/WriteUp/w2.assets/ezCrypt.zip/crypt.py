import random
import string


def gen_random_key(secret_seed):
    # fack random key ???
    random_poor = []
    random.seed(secret_seed)
    for _ in range(10):
        random_poor.append(str(random.random())[2:])
    return (random_poor[-1], random_poor[0])


def decode_flag1(flag_part1, random_key):
    assert (len(flag_part1) == 16 and len(flag_part1) == 16)
    flag_arr = bytearray(flag_part1)
    res = ""
    for i in range(len(flag_arr)):
        res += chr(flag_arr[i] ^ int(random_key[i]))
    return res


def decode_flag2(flag_part2, random_key):
    assert (len(flag_part2) == 16 and len(flag_part2) == 16)
    res = ""
    for index, value in enumerate(flag_part2):
        temp_check = value + int(random_key[index])
        if (chr(temp_check) in string.printable):
            res += chr(temp_check)
        else:
            res += chr(value - int(random_key[index]))
    return res


if __name__ == '__main__':
    # the result is: alin|]^edk7neYCkR2xrbHap3r~#@,&~
    flag = b"????????????????"
    key = gen_random_key('???????????')
    encode_01 = decode_flag1(flag[0:16], key[0])
    encode_02 = decode_flag2(flag[16:], key[1])
    print(encode_01 + encode_02)
